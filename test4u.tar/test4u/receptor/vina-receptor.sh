#!/bin/bash

##Replace 4or0 with pdb ID code, %s/aaa/aaa
##Comment out RenumberResid.py if you dont need it, pdb4amber renumbers residues to start at 1, so you might have to use it, designate X as starting residue number. 


#get input files

read -p 'PDB ID Code: ' pdbid
read -p 'Chain of Interest (Uppercase): ' chain
read -p 'PROPKA Protonation pH (Integer/Decimal): ' ph
read -p 'PDB2PQR Optimization Forcefield (options: amber, charmm-under construction): ' ff
read -p 'PDB2PQR Output Scheme (options: amber, charmm-under construction): ' fff
read -p 'Starting Residue Number in Structure File (Integer): ' resnum

echo 1. Structure file $pdbid.pdb will be extracted, only $chain will be persevered, all co-crystallized entities will be deleted.
echo 2. Structure file will be protonated at pH $ph and optimized, i.e add missing atoms, with the $ff forcefield.
echo 3. Structure file will be renumbered at starting residue number $resnum. 
echo 4. Final structure file will be called receptor.pdb.


read -p "Continue? (Y/N): " confirm && [[ $confirm == [yY] || $confirm == [yY][eE][sS] ]] || exit 1


python pdb2pqr.py --with-ph=$ph --ph-calc-method=propka --drop-water --apbs-input --whitespace --ff=$ff --ffout=$fff --chain --verbose --summary $pdbid $pdbid-pqr.pdb


awk -v chain=$chain '$5==chain {print $0}' $pdbid-pqr.pdb > $pdbid-pqr-$chain.pdb

pdb4amber -i $pdbid-pqr-$chain.pdb -o $pdbid-pqr-$chain-clean.pdb 

python RenumberResid.py -$resnum $pdbid-pqr-$chain-clean.pdb > receptor.pdb
