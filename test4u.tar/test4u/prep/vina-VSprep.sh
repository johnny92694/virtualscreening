#!/bin/bash
vmd="/Applications/VMD-1.9.3.app/Contents/vmd/vmd_MACOSXX86"

####receptor prep#####
(cd ../receptor ; ./vina-receptor.sh) 

read -p "Please check & edit receptor.pdb before continuing. Continue? (Y/N): " confirm && [[ $confirm == [yY] || $confirm == [yY][eE][sS] ]] || exit 1


####get input files#####

(cd ../ligand ; cp *.mol2 ../prep)
(cd ../receptor ; cp receptor.pdb ../prep) 

####prepare receptor######
./pythonsh prepare_receptor4.py -r receptor.pdb -o receptor.pdbqt

####prepare ligand#####

END=$(ls -1p *.mol2 | wc -l)

for i in $(seq 1 $END)
do 
   
 ./pythonsh prepare_ligand4.py -l $i.mol2 -o ligand_$i.pdbqt 

done

#Prep VS

read -p 'How many times would you like to run this virtual screening (Integer): ' vs

for m in $(seq 1 $vs)
do
  
 mkdir ../virtual-screen-$m.sh
 cp virtual-screen.sh ../virtual-screen-$m.sh
 cp vina ../virtual-screen-$m.sh 
 cp vina_split ../virtual-screen-$m.sh 
 cp conf.txt ../virtual-screen-$m.sh 
 cp *.pdbqt ../virtual-screen-$m.sh
 cp pythonsh ../virtual-screen-$m.sh
 cp pdbqt_to_pdb.py ../virtual-screen-$m.sh   
 cp receptor.pdb ../virtual-screen-$m.sh 
 cp RenumberResid.py ../virtual-screen-$m.sh 
 cp prepare_ligand4.py ../virtual-screen-$m.sh
 cp prepare_receptor4.py ../virtual-screen-$m.sh
 cp UniqueAtomName.tcl ../virtual-screen-$m.sh 
done

echo Ligands default chain is D. 
read -p 'How many ligands did you prepare for this screening? (Integer): ' lig

read -p "About to execute $vs virtual screening runs for $lig ligands. Continue? (Y/N): " confirm && [[ $confirm == [yY] || $confirm == [yY][eE][sS] ]] || exit 1


#Execute VS

for d in $(seq 1 $vs)
do

 (cd ../virtual-screen-$d.sh ; ./virtual-screen.sh)

done


echo "1. You have completed your virtual screenings!" 
read -p "2. Would you like to split the output file, convert pdbqts to pdb, merge to make complex pdbs, and organize log files? (Y/N): " confirm && [[ $confirm == [yY] || $confirm == [yY][eE][sS] ]] || exit 1



#VinaSplit

for e in $(seq 1 $vs)
do
  cd ../virtual-screen-$e.sh
   for f in $(seq 1 $lig) 
   do
    (cp vina_split ligand_$f ; cp pythonsh ligand_$f ; cp pdbqt_to_pdb.py ligand_$f ; cp RenumberResid.py ligand_$f ; cp receptor.pdbqt ligand_$f ; cp prepare_ligand4.py ligand_$f ; cp prepare_receptor4.py ligand_$f ; cp UniqueAtomName.tcl ligand_$f ; cd ligand_$f ; ./vina_split --input out.pdbqt --ligand ligand-$f- ; mv out.pdbqt results.pdbqt)
   done
done


#ligand pdbqt to pdbqt to add hydrogens

for n in $(seq 1 $vs); do
 cd ../virtual-screen-$n.sh
  for p in $(seq 1 $lig); do
   cd ligand_$p 
   find ./ -maxdepth 1 -type f -name 'liga*.pdbqt' -execdir ./pythonsh prepare_ligand4.py -l {} -A hydrogens -U='' \;
   cd ../
  done
done


#receptor pdbqt to pdbqt to add hydrogens
for n in $(seq 1 $vs); do
 cd ../virtual-screen-$n.sh
  for p in $(seq 1 $lig); do
   cd ligand_$p 
   find ./ -maxdepth 1 -type f -name 'rece.pdbqt' -execdir ./pythonsh prepare_receptor4.py -l {} -A hydrogens -U='' \;
   cd ../
  done
done


#pdbqt to pdb
for g in $(seq 1 $vs); do
 cd ../virtual-screen-$g.sh
  for h in $(seq 1 $lig); do
   cd ligand_$h 
   find ./ -maxdepth 1 -type f -name 'liga*.pdbqt' -execdir ./pythonsh pdbqt_to_pdb.py -f {} \;
   find ./ -maxdepth 1 -type f -name 'rece*.pdbqt' -execdir ./pythonsh pdbqt_to_pdb.py -f {} \;
   $vmd -dispdev text -e UniqueAtomName.tcl 
   cd ../
  done
done

#combine receptor pdb and best ligand pdb

for l in $(seq 1 $vs); do
 cd ../virtual-screen-$l.sh
  for j in $(seq 1 $lig); do
    cd ligand_$j 
    for k in lig*.pdb; do cat receptor.pdb "$k" >"receptor_$k"; done 
    cd ../
  done
done

#log
mkdir ../logs 
for g in $(seq 1 $vs); do
 cd ../virtual-screen-$g.sh
  for h in $(seq 1 $lig); 
  do
    cd ligand_$h 
    cp log.txt ./ligand_"$h"_virtualscreen_"$g"_log.txt
    cp ligand_"$h"_virtualscreen_"$g"_log.txt ../../logs
    cd ../
  done
done



#log
cd ../logs
sed -i '' '/WARNING/d' *log.txt 

for h in $(seq 1 $lig)
do
 for g in $(seq 1 $vs)
 do  
  find ./ -type f -name "ligand_"$h"_virtualscreen_"$g"*" -execdir sed -n 26p {} \; >> ligand_"$h"_logs.txt
 done 
echo "ligand_"$h"_logs" >> ligand_"$h"_logs.txt
done

#log
cat *logs.txt >> summary_logs.txt
 


#prep for MD
echo "1. You've completed splitting the output files, converting pdbqts to pdb, making complex pdbs, and organized log files!"
read -p "2. Would you like to prep your complex files for amber MD simulation? (Y/N): " confirm && [[ $confirm == [yY] || $confirm == [yY][eE][sS] ]] || exit 1
read -p '3. What starting residue number would you like your complex pdbs to begin with (recommended: always start with 1 for MD index): ' resnum2

for g in $(seq 1 $vs); do
 cd ../virtual-screen-$g.sh
  for h in $(seq 1 $lig); 
  do
    cd ligand_$h 
    	for i in receptor_ligand*.pdb; 
    	do 
		python RenumberResid.py -$resnum2 "$i" > "MD0_$i"
     		pdb4amber -i "MD0_$i" -o "MD1_$i"
                python RenumberResid.py -$resnum2 "MD1_$i" > "MD_$i" 
    	done
    cd ../
  done
done

#folder for MD

for g in $(seq 1 $vs); do
 cd ../virtual-screen-$g.sh
  for h in $(seq 1 $lig); 
  do
    cd ligand_$h 
	mkdir MD_ligand_$h
    	cp MD_receptor* ./MD_ligand_$h/
    cd ../
  done
done

echo "You're done!" 


